interface ReceptieInterface {}
