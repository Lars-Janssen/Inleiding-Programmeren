interface KamerInterface {
    VasteGrootteGroep<Gast> getGasten();
}
