/**
 * Naam         :  Lars Janssen
 * UvAnetID     :  12882712
 * Studie       :  BSc Informatica
 *
 *      Dit programma print mijn naam in
 *      Ascii-art. Het print Lars.
 */

public class Deel1
{
    public static void main(String[] args)
    {
        System.out.println(".____");
        System.out.println("|    |   _____ _______  ______");
        System.out.println("|    |   \\__  \\\\_  __ \\/  ___/");
        System.out.println("|    |___ / __ \\|  | \\/\\___ \\ ");
        System.out.println("|_______ (____  /__|  /____  >");
        System.out.println("        \\/    \\/           \\/");
    }
}